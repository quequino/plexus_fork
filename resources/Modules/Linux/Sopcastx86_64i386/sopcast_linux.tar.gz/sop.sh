$PWD/ld-linux.so.2 --library-path lib ./sp-sc-auth sop://broker.sopcast.com:3912/$1 1234 12345 
